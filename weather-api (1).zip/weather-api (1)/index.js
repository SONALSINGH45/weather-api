
const axios = require('axios');
const express = require("express");
const fs=require("fs")
const allCities = require('./csvjson.js');
//var Promise = require('promise');
//const mongoose = require("mongoose");
const app = express();
app.use(express.json());

app.get('/weatherinfo', async (req, res) => {
  //  const searchTerm = req.query.search;
  //  console.log("test",searchTerm)
    try {
        const resp = await Promise.all([
          axios.get("https://apidev.accuweather.com/currentconditions/v1/3588312?apikey=4809f0f4fe774698a5e4e963f961a67f"),
          axios.get("https://apidev.accuweather.com/airquality/v2/currentconditions/3588312?apikey=4809f0f4fe774698a5e4e963f961a67f&pollutants=1&language=en-us"),
          axios.get("http://apidev.accuweather.com/locations/v1/geoposition/search.json?q=28.5293,77.1484&apikey=4809f0f4fe774698a5e4e963f961a67f")
        ]);
        const data = resp.map((r) => r.data);
        // fs.readFile("csvjson.js","UTF-8",(err,data)=>{
        //   // console.log(data);
        //    const allCities = JSON.parse(data);
        //    const selectedCity= allCities.find(item => item('City/Town') == req.query.searchTerm)
        //  res.send(selectedCity)
        //  })
        console.log(data.flat());
        res.send(data.flat())
      } catch (e) {
        throw Error("Promise failed",e);
      }
  })


  const redis = require('redis');
const { promises } = require('stream');
const client = redis.createClient(
  
);

client.connect();
client.on('error', err => {
    console.log('Error ' + err);
});
client.on("connect",()=>{
  console.log("connected")
})
//retrive data from cache
app.get("/weatherinfo2", async (req, res) => {
  const searchTerm = req.query.search;

  // if user doesnt pass any search term , will thorw the exception
  if (!searchTerm) {
    throw  'Search term is not found';
  }

  try {
    // will try to get city information from array (later it will come from SOLR)
    const selectedCity = allCities.find(item => item['City/Town'].toLowerCase() == searchTerm.toLowerCase())
    console.log("selectedCity", selectedCity);

    
    if (selectedCity && selectedCity.lat && selectedCity.long && !selectedCity.Key) {
      // will try to get city information from ACCUWEATHER
      const CityInfo = await axios.get(`http://apidev.accuweather.com/locations/v1/geoposition/search.json?q=${selectedCity.lat},${selectedCity.long}&apikey=4809f0f4fe774698a5e4e963f961a67f`)
      console.log(CityInfo);

      if (CityInfo && CityInfo.length > 0) {
        const currentCity = CityInfo[0];

        const response = await Promise.all([
          axios.get(`https://apidev.accuweather.com/currentconditions/v1/${currentCity.Key}?apikey=4809f0f4fe774698a5e4e963f961a67f`),
          axios.get(`https://apidev.accuweather.com/airquality/v2/currentconditions/${currentCity['Key']}?apikey=4809f0f4fe774698a5e4e963f961a67f&pollutants=1&language=en-us`)
        ])


        res.send(response);




      } else {
        // if city inforamtion is not found in our SOLR or static JSON
        throw new Error('City not found');
      }

    } else {

      // if city inforamtion is not found in our SOLR or static JSON
      throw new Error('City not found');
    }



  } catch (e) {
    console.log(e)
    throw Error("Promise failed", e);
  }
})
              
      app.listen(9000,()=>{
        console.log("on port on port 9000")
        //console.log("jjjbbb")
    })
    

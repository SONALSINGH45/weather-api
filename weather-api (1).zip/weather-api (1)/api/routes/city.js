const express =require("express");
const res = require("express/lib/response");
const router = express.Router()
const cityarray = require('../../csvjson')
//const app = express();

//import * as cityarray from '../../csvjson.json';
// app.listen(9000,()=>{
//        console.log("on port on port 9000")
//         console.log("jjjbbb")
//      })

router.get("/getweatherreport",async(req,res)=>{
    console.log("inside post fuction");
    //const cityinfor = cityarray.find(req.body.cityname.toLowerCase() == x['City/Town'].toLowerCase()


   //);


    // solr 


    if (cityinfor && cityinfor.key) {
        const citykey = cityinfor.key;


   const res =   await  Promise.all(
            "https://apidev.accuweather.com/currentconditions/v1/" + citykey + "?apikey=4809f0f4fe774698a5e4e963f961a67f",
            "https://apidev.accuweather.com/airquality/v2/currentconditions/" + citykey + "?apikey=4809f0f4fe774698a5e4e963f961a67f&pollutants=1&language=en-us"

        )
    }


    return resp.json(res);

    //res.send("posted");
})
router.get("/weatherinfo1", async(req,res)=>{
    
        try {
          return await Promise.all([
            axios.get("https://apidev.accuweather.com/currentconditions/v1/3588312?apikey=4809f0f4fe774698a5e4e963f961a67f"
            ),
            axios.get("https://apidev.accuweather.com/airquality/v2/currentconditions/3588312?apikey=4809f0f4fe774698a5e4e963f961a67f&pollutants=1&language=en-us"
            ),
            axios.get("http://apidev.accuweather.com/locations/v1/geoposition/search.json?q=28.5293,77.1484&apikey=4809f0f4fe774698a5e4e963f961a67f")
          ]);
          const data = res.map((res) => res.data);
          //console.log(data.flat());
          res.send(data)
        } catch {
          throw Error("Promise failed");
        }

})

module.exports=router;
//module.exports=
